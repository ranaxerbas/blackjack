using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BlackJack_vb
{
  /// <summary>
  /// Interaction logic for Game_.xaml
  /// </summary>
  public partial class Game_ : Window
  {
    Businessclass_game _business = new Businessclass_game();

    public Game_()
    {
      InitializeComponent();
      btnHit.IsEnabled = true;
    }

    private void btnSplit_Click(object sender, RoutedEventArgs e)
    {
      //eerste 2kaarten weergeven
      int totalvalueGamer = 0, totalvalueBank = 0, cardvalueGamer1, cardvalueGamer2, cardvalueBank1, cardvalueBank2;

      string strCardGamer1 = _business.getCard();
      cardvalueGamer1 = _business.getValue();

      string strCardGamer2 = _business.getCard();
      cardvalueGamer2 = _business.getValue();

      totalvalueGamer = cardvalueGamer1 + cardvalueGamer2;

      txtbxGamer.Text = strCardGamer1 + " " +strCardGamer2;
      lblScoreGamer.Content = totalvalueGamer;

      string strCardBank1 = _business.getCard();
      cardvalueBank1 = _business.getValue();

      string strCardBank2 = _business.getCard();
      cardvalueBank2 = _business.getValue();

      totalvalueBank = cardvalueBank1 + cardvalueBank2;

      txtbxBank.Text = strCardBank1 + " " + strCardBank2;
      lblScoreBank.Content = totalvalueBank;
    }

    private void btnHit_Click(object sender, RoutedEventArgs e)
    {
      int totalvalueGamer, totalvalueBank, cardvalueGamer3, cardvalueBank3, cardvalueGamer4, cardvalueBank4;
      totalvalueGamer = Convert.ToInt16(lblScoreGamer.Content);
      totalvalueBank = Convert.ToInt16(lblScoreBank.Content);

      if (totalvalueGamer < 21)
      {
        MessageBox.Show("Your result is" + totalvalueGamer + ". Do you want to stop or continue to play?, If you want to continue press the button 'HIT' for a new card but if you want to stop press the button 'Stand'.");

        string strGamerCard3 = _business.getCard();
        cardvalueGamer3 = _business.getValue();

        totalvalueGamer = totalvalueGamer + cardvalueGamer3;

        txtbxGamer.Text = strGamerCard3;
        lblScoreGamer.Content = totalvalueGamer;

        string strBankCard3 = _business.getCard();
        cardvalueBank3 = _business.getValue();

        totalvalueBank = totalvalueBank + cardvalueBank3;

        txtbxBank.Text = strBankCard3;
        lblScoreBank.Content = totalvalueBank;

        txtbxBank.Text = string.Empty;
      }
      if (totalvalueGamer >= 21)
      {
        MessageBox.Show("You've lost!");
      }
      else if (totalvalueGamer == 21)
      {
        MessageBox.Show("You've won!");
      }
      else
      {
        MessageBox.Show("Your result is" + totalvalueGamer + ". Do you want to stop or continue to play?, If you want to continue press the button 'HIT' for a new card but if you want to stop press the button 'Stand'.");
      }

      if (totalvalueGamer < 21)
      {
        string strGamerCard4 = _business.getCard();
        cardvalueGamer4 = _business.getValue();

        totalvalueGamer = totalvalueGamer + cardvalueGamer4;

        txtbxGamer.Text = strGamerCard4;
        lblScoreGamer.Content = totalvalueGamer;

        string strBankCard4 = _business.getCard();
        cardvalueBank4 = _business.getValue();

        totalvalueBank = totalvalueBank + cardvalueBank4;

        txtbxBank.Text = strBankCard4;
        lblScoreBank.Content = totalvalueBank;

        txtbxBank.Text = string.Empty;
      }
      else if (totalvalueGamer > 21)
      {
        MessageBox.Show("You've lost!");
      }
      else if (totalvalueGamer >= 21)
      {
        MessageBox.Show("Congrats, you've won!");
      }
    }

    private void btnStand_Click(object sender, RoutedEventArgs e)
    {
      btnHit.IsEnabled = false;
      btnStand.IsEnabled = false;
      Random rnd = new Random();
      int count = Convert.ToInt16(lblScoreBank.Content);
      int Bankscore_ = rnd.Next(count);
      int totalvalueGamer;
      totalvalueGamer = Convert.ToInt16(lblScoreGamer.Content);

      if (totalvalueGamer == 21)
      {
        MessageBox.Show("Congrats, you've won!");
      }
    }
    private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
      int budget;
      budget = Convert.ToInt16(lblBudget.Content);

      budgetSlider.Maximum = budget;
      budgetSlider.Minimum = budget * 0.1;
    }
  }
}
