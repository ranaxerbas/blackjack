using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack_vb
{
  internal class Businessclass_game
  {
    public Game_ _game = new Game_();
    int _card1, _value;
    string _cardresult1;

    public string getCard()
    {
      switch (_card1)
      {
        case 1:
          _cardresult1 = "Heart 1";
          _value = 1;
          break;
        case 2:
          _cardresult1 = "Heart 2";
          _value = 2;
          break;
        case 3:
          _cardresult1 = "Heart 3";
          _value = 3;
          break;
        case 4:
          _cardresult1 = "Heart 4";
          _value = 4;
          break;
        case 5:
          _cardresult1 = "Heart 5";
          _value = 5;
          break;
        case 6:
          _cardresult1 = "Heart 6";
          _value = 6;
          break;
        case 7:
          _cardresult1 = "Heart 7";
          _value = 7;
          break;
        case 8:
          _cardresult1 = "Heart 8";
          _value = 8;
          break;
        case 9:
          _cardresult1 = "Heart 9";
          _value = 9;
          break;
        case 10:
          _cardresult1 = "Heart 10";
          _value = 10;
          break;
        case 11:
          _cardresult1 = "Jack of Hearts";
          _value = 11;
          break;
        case 12:
          _cardresult1 = "Queen of Hearts";
          _value = 12;
          break;
        case 13:
          _cardresult1 = "King of Hearts";
          _value = 13;
          break;
        case 14:
          _cardresult1 = "Club 1";
          _value = 1;
          break;
        case 15:
          _cardresult1 = "Club 2";
          _value = 2;
          break;
        case 16:
          _cardresult1 = "Club 3";
          _value = 3;
          break;
        case 17:
          _cardresult1 = "Club 4";
          _value = 4;
          break;
        case 18:
          _cardresult1 = "Club 5";
          _value = 5;
          break;
        case 19:
          _cardresult1 = "Club 6";
          _value = 6;
          break;
        case 20:
          _cardresult1 = "Club 7";
          _value = 7;
          break;
        case 21:
          _cardresult1 = "Club 8";
          _value = 8;
          break;
        case 22:
          _cardresult1 = "Club 9";
          _value = 9;
          break;
        case 23:
          _cardresult1 = "Club 10";
          _value = 10;
          break;
        case 24:
          _cardresult1 = "Jack of Clubs";
          _value = 11;
          break;
        case 25:
          _cardresult1 = "Queen of Clubs";
          _value = 12;
          break;
        case 26:
          _cardresult1 = "King of Clubs";
          _value = 13;
          break;
        case 27:
          _cardresult1 = "Spade 1";
          _value = 1;
          break;
        case 28:
          _cardresult1 = "Spade 2";
          _value = 2;
          break;
        case 29:
          _cardresult1 = "Spade 3";
          _value = 3;
          break;
        case 30:
          _cardresult1 = "Spade 4";
          _value = 4;
          break;
        case 31:
          _cardresult1 = "Spade 5";
          _value = 5;
          break;
        case 32:
          _cardresult1 = "Spade 6";
          _value = 6;
          break;
        case 33:
          _cardresult1 = "Spade 7";
          _value = 7;
          break;
        case 34:
          _cardresult1 = "Spade 8";
          _value = 8;
          break;
        case 35:
          _cardresult1 = "Spade 9";
          _value = 9;
          break;
        case 36:
          _cardresult1 = "Spade 10";
          _value = 10;
          break;
        case 37:
          _cardresult1 = "Jack of Spades";
          _value = 11;
          break;
        case 38:
          _cardresult1 = "Queen of Spades";
          _value = 12;
          break;
        case 39:
          _cardresult1 = "King of Spades";
          _value = 13;
          break;
        case 40:
          _cardresult1 = "Diamond 1";
          _value = 1;
          break;
        case 41:
          _cardresult1 = "Diamond 2";
          _value = 2;
          break;
        case 42:
          _cardresult1 = "Diamond 3";
          _value = 3;
          break;
        case 43:
          _cardresult1 = "Diamond 4";
          _value = 4;
          break;
        case 44:
          _cardresult1 = "Diamond 5";
          _value = 5;
          break;
        case 45:
          _cardresult1 = "Diamond 6";
          _value = 6;
          break;
        case 46:
          _cardresult1 = "Diamond 7";
          _value = 7;
          break;
        case 47:
          _cardresult1 = "Diamond 8";
          _value = 8;
          break;
        case 48:
          _cardresult1 = "Diamond 9";
          _value = 9;
          break;
        case 49:
          _cardresult1 = "Diamond 10";
          _value = 10;
          break;
        case 50:
          _cardresult1 = "Jack of Diamonds";
          _value = 11;
          break;
        case 51:
          _cardresult1 = "Queen of Diamonds";
          _value = 12;
          break;
        case 52:
          _cardresult1 = "King of Diamonds";
          _value = 13;
          break;
      }
      return _cardresult1;
    }

    public int getValue()
    {
      return _value;
    }
  }
}
