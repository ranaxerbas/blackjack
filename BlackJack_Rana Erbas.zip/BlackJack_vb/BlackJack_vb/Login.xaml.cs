using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BlackJack_vb
{
  /// <summary>
  /// Interaction logic for Login.xaml
  /// </summary>
  public partial class Login : Window
  {
    public Login()
    {
      InitializeComponent();
    }

    private void btnVerify_Click(object sender, RoutedEventArgs e)
    {
      Window editor = new Game_();
      editor.Show();
      this.Close();


      string _username = txtUsername.Text;


      string message = ("Welcome " + _username + " druk op OK om het spel te laten beginnen. Nog veel succes!!");
      string title = "Welcome";
      MessageBox.Show(message, title);
    }

    private void txtPassword_TextChanged(object sender, TextChangedEventArgs e)
    {
        
    }
  }
}
